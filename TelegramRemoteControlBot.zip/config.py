
# config.py
TOKEN = '7470493849:AAH2_jREQoTHnjUe5sAQmA_B_TWLsePbAdc'
YOUR_CHAT_ID = '845800521'
FILE_IO_API_URL = "https://file.io"